import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-VEPYSEDS.js";
import "./chunk-Z3VEQW6T.js";
import "./chunk-RLKVDIIJ.js";
import "./chunk-YLHXK2KV.js";
import "./chunk-IJX55SC6.js";
import "./chunk-GOMI4DH3.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
