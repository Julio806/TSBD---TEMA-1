export interface Student {
  id?: number;
  nombre: string;
  apellidoP: string;
  apellidoM: string;
  cursoId?: number;
}
