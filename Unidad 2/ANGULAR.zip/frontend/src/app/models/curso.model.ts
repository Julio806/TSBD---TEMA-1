export interface Curso {
  id?: number;
  nombre: string;
  docente?: string;
}