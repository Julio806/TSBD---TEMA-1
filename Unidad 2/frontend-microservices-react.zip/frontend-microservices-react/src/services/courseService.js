import axios from "axios";

const API_URL = "http://localhost:9090/api/cursos"; // 👈 cambia el 9090 por el puerto real

export const getAllCourses = () => axios.get(`${API_URL}/all`);
export const getCourseById = (id) => axios.get(`${API_URL}/search/${id}`);
export const createCourse = (curso) => axios.post(`${API_URL}/create`, curso);
export const updateCourse = (id, curso) => axios.put(`${API_URL}/update/${id}`, curso);
export const deleteCourse = (id) => axios.delete(`${API_URL}/delete/${id}`);
