export const API_BASES = {
  students: "http://localhost:8090/api/students",
  courses: "http://localhost:9090/api/cursos",
};
