import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home"; // ✅ este sí está bien
import StudentsList from "./pages/Students/StudentsList"; // 👈 CORREGIDO
import StudentForm from "./pages/Students/StudentForm";   // 👈 CORREGIDO
import CoursesList from "./pages/Courses/CoursesList";    // 👈 CORREGIDO
import CourseForm from "./pages/Courses/CourseForm";      // 👈 CORREGIDO
import "./App.css";


function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/students" element={<StudentsList />} />
        <Route path="/students/new" element={<StudentForm />} />
        <Route path="/students/edit/:id" element={<StudentForm />} />
        <Route path="/courses" element={<CoursesList />} />
        <Route path="/courses/new" element={<CourseForm />} />
        <Route path="/courses/edit/:id" element={<CourseForm />} />
      </Routes>
    </Router>
  );
}

export default App;
