import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="container home">
      <h1>Microservicios con React</h1>
      <p>Selecciona una opción:</p>
      <div className="buttons">
        <Link to="/students" className="btn">Gestionar Estudiantes</Link>
        <Link to="/courses" className="btn">Gestionar Cursos</Link>
      </div>
    </div>
  );
}
