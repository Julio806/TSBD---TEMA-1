import React, { useEffect, useState } from "react";
import { createStudent, getStudentById, updateStudent } from "../../services/studentService";
import { useNavigate, useParams } from "react-router-dom";

const StudentForm = () => {
  const [student, setStudent] = useState({
    nombre: "",
    apellidoP: "",
    apellidoM: "",
    cursoId: ""
  });

  const navigate = useNavigate();
  const { id } = useParams();

  // 🔹 Cargar estudiante si es edición
  useEffect(() => {
    if (id) {
      getStudentById(id)
        .then((res) => setStudent(res.data))
        .catch((err) => console.error("❌ Error al obtener estudiante:", err));
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent({ ...student, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (id) {
        await updateStudent(id, student);
        alert("✅ Estudiante actualizado correctamente");
      } else {
        await createStudent(student);
        alert("✅ Estudiante creado correctamente");
      }
      navigate("/students");
    } catch (error) {
      console.error("❌ Error al guardar estudiante:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h2>{id ? "✏️ Editar Estudiante" : "➕ Nuevo Estudiante"}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Nombre</label>
          <input
            type="text"
            className="form-control"
            name="nombre"
            value={student.nombre}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label>Apellido Paterno</label>
          <input
            type="text"
            className="form-control"
            name="apellidoP"
            value={student.apellidoP}
            onChange={handleChange}
          />
        </div>

        <div className="mb-3">
          <label>Apellido Materno</label>
          <input
            type="text"
            className="form-control"
            name="apellidoM"
            value={student.apellidoM}
            onChange={handleChange}
          />
        </div>

        <div className="mb-3">
          <label>ID del Curso</label>
          <input
            type="number"
            className="form-control"
            name="cursoId"
            value={student.cursoId}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="btn btn-success me-2">
          💾 Guardar
        </button>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate("/students")}
        >
          🔙 Volver
        </button>
      </form>
    </div>
  );
};

export default StudentForm;
