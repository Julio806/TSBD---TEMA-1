import React, { useEffect, useState } from "react";
import { getStudents, deleteStudent } from "../../services/studentService";
import { useNavigate } from "react-router-dom";

const StudentsList = () => {
  const [students, setStudents] = useState([]);
  const navigate = useNavigate();

  // 🔹 Cargar estudiantes al montar el componente
  const loadStudents = async () => {
    try {
      const response = await getStudents();
      setStudents(response.data);
    } catch (error) {
      console.error("❌ Error al cargar estudiantes:", error);
    }
  };

  useEffect(() => {
    loadStudents();
  }, []);

  // 🔹 Eliminar estudiante
  const handleDelete = async (id) => {
    if (window.confirm("¿Seguro que deseas eliminar este estudiante?")) {
      try {
        await deleteStudent(id);
        loadStudents();
      } catch (error) {
        console.error("❌ Error al eliminar estudiante:", error);
      }
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>📚 Lista de Estudiantes</h2>
        <button
          className="btn btn-primary"
          onClick={() => navigate("/students/new")}
        >
          ➕ Nuevo Estudiante
        </button>
      </div>

      {students.length === 0 ? (
        <p>No hay estudiantes registrados.</p>
      ) : (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Apellido Paterno</th>
              <th>Apellido Materno</th>
              <th>Curso ID</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s.id}>
                <td>{s.id}</td>
                <td>{s.nombre}</td>
                <td>{s.apellidoP}</td>
                <td>{s.apellidoM}</td>
                <td>{s.cursoId}</td>
                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => navigate(`/students/edit/${s.id}`)}
                  >
                    ✏️ Editar
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(s.id)}
                  >
                    🗑️ Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default StudentsList;
