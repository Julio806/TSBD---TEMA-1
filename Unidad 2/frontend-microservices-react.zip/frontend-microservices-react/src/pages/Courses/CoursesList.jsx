import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { getAllCourses, deleteCourse } from "../../services/courseService";

export default function CoursesList() {
  const [courses, setCourses] = useState([]);
  const navigate = useNavigate();

  const loadCourses = async () => {
    try {
      const res = await getAllCourses();
      setCourses(res.data);
    } catch (error) {
      console.error("Error cargando cursos:", error);
      Swal.fire("Error", "No se pudieron cargar los cursos", "error");
    }
  };

  useEffect(() => {
    loadCourses();
  }, []);

  const handleDelete = async (id) => {
    const confirm = await Swal.fire({
      title: "¿Eliminar curso?",
      text: "Esta acción no se puede deshacer",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
    });

    if (confirm.isConfirmed) {
      try {
        await deleteCourse(id);
        Swal.fire("Eliminado", "Curso eliminado correctamente", "success");
        loadCourses();
      } catch (error) {
        Swal.fire("Error", "No se pudo eliminar el curso", "error");
      }
    }
  };

  return (
    <div className="container" style={{ maxWidth: "900px", margin: "50px auto" }}>
      <div className="card shadow p-4">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h2 className="text-dark">Lista de Cursos</h2>
          <button className="btn btn-primary" onClick={() => navigate("/courses/new")}>
            + Nuevo Curso
          </button>
        </div>
        <table className="table table-bordered table-striped table-hover text-center">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Docente</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {courses.length > 0 ? (
              courses.map((c) => (
                <tr key={c.id}>
                  <td>{c.id}</td>
                  <td>{c.nombre}</td>
                  <td>{c.docente}</td>
                  <td>
                    <button
                      className="btn btn-warning btn-sm me-2"
                      onClick={() => navigate(`/courses/edit/${c.id}`)}
                    >
                      Editar
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDelete(c.id)}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No hay cursos registrados.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
