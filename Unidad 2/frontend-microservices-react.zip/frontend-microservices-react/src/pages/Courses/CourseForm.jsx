import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";
import { createCourse, getCourseById, updateCourse } from "../../services/courseService";

export default function CourseForm() {
  const [curso, setCurso] = useState({ nombre: "", docente: "" });
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      getCourseById(id).then((res) => setCurso(res.data));
    }
  }, [id]);

  const handleChange = (e) => {
    setCurso({ ...curso, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (id) {
        await updateCourse(id, curso);
        Swal.fire("Actualizado", "El curso fue actualizado con éxito", "success");
      } else {
        await createCourse(curso);
        Swal.fire("Creado", "El curso fue creado correctamente", "success");
      }
      navigate("/courses");
    } catch (error) {
      Swal.fire("Error", "Ocurrió un problema al guardar el curso", "error");
      console.error(error);
    }
  };

  return (
    <div className="container" style={{ maxWidth: "600px", margin: "50px auto" }}>
      <div className="card shadow p-4">
        <h2 className="text-center mb-4">
          {id ? "Editar Curso" : "Nuevo Curso"}
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Nombre del Curso</label>
            <input
              type="text"
              name="nombre"
              className="form-control"
              value={curso.nombre}
              onChange={handleChange}
              required
              placeholder="Ej. Programación en Java"
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Docente</label>
            <input
              type="text"
              name="docente"
              className="form-control"
              value={curso.docente}
              onChange={handleChange}
              required
              placeholder="Ej. Juan Pérez"
            />
          </div>
          <div className="text-center">
            <button type="submit" className="btn btn-success me-2">
              💾 Guardar
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate("/courses")}
            >
              🔙 Volver
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
