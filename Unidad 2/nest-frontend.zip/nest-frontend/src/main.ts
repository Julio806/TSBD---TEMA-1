import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import { engine } from 'express-handlebars';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  const viewsPath = join(__dirname, '..', 'src', 'views');

  // Configurar Handlebars con layout y helpers
  app.engine(
    'hbs',
    engine({
      extname: 'hbs',
      defaultLayout: 'layout',           // tu layout se llama layout.hbs
      layoutsDir: join(viewsPath, 'layouts'), // carpeta layouts
      partialsDir: viewsPath,            // si tienes partials
      helpers: {
        ifEquals: (arg1: any, arg2: any) => arg1 == arg2,
      },
    }),
  );

  app.setBaseViewsDir(viewsPath);
  app.setViewEngine('hbs');

  await app.listen(3000);
  console.log(`🚀 Frontend NestJS corriendo en: http://localhost:3000`);
}
bootstrap();
