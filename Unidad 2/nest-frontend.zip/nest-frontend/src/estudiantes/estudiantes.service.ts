import { Injectable } from '@nestjs/common';
import axios from 'axios';
@Injectable()
export class EstudiantesService {
  private baseUrl = 'http://localhost:8090/api/students';
  async obtenerEstudiantes() {
    const { data } = await axios.get(this.baseUrl);
    return data;
  }
  async obtenerEstudiante(id: number) {
    const { data } = await axios.get(`${this.baseUrl}/${id}`);
    return data;
  }
  async crearEstudiante(estudiante: any) {
    const { data } = await axios.post(this.baseUrl, estudiante);
    return data;
  }
  async actualizarEstudiante(id: number, estudiante: any) {
    const { data } = await axios.put(`${this.baseUrl}/${id}`, estudiante);
    return data;
  }
  async eliminarEstudiante(id: number) {
    await axios.delete(`${this.baseUrl}/${id}`);
  }
}
