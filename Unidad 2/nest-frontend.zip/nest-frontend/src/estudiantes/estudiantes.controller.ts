import { Controller, Get, Render, Post, Body, Param, Redirect } from '@nestjs/common';
import { EstudiantesService } from './estudiantes.service';

@Controller('estudiantes')
export class EstudiantesController {
  constructor(private readonly estudiantesService: EstudiantesService) {}

  @Get()
  @Render('estudiantes')
  async listarEstudiantes() {
    const estudiantes = await this.estudiantesService.obtenerEstudiantes();
    return { estudiantes };
  }

  @Get('crear')
  @Render('crear-estudiante')
  crearFormulario() {
    return {};
  }

  @Post('crear')
  @Redirect('/estudiantes')
  async crear(@Body() body: any) {
    await this.estudiantesService.crearEstudiante(body);
  }

  @Get('editar/:id')
  @Render('editar-estudiante')
  async editarFormulario(@Param('id') id: number) {
    const estudiante = await this.estudiantesService.obtenerEstudiante(id);
    return { estudiante };
  }

  @Post('editar/:id')
  @Redirect('/estudiantes')
  async editar(@Param('id') id: number, @Body() body: any) {
    await this.estudiantesService.actualizarEstudiante(id, body);
  }

  @Get('eliminar/:id')
  @Redirect('/estudiantes')
  async eliminar(@Param('id') id: number) {
    await this.estudiantesService.eliminarEstudiante(id);
  }
}
