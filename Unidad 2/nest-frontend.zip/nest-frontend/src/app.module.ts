import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { EstudiantesService } from './estudiantes/estudiantes.service';
import { EstudiantesController } from './estudiantes/estudiantes.controller';
import { CursosService } from './cursos/cursos.service';
import { CursosController } from './cursos/cursos.controller';

@Module({
  imports: [],
  controllers: [AppController, EstudiantesController, CursosController],
  providers: [EstudiantesService, CursosService],
})
export class AppModule {}
