import { Controller, Get, Render, Post, Body, Param, Redirect } from '@nestjs/common';
import { CursosService } from './cursos.service';

@Controller('cursos')
export class CursosController {
  constructor(private readonly cursosService: CursosService) {}

  @Get()
  @Render('cursos')
  async listarCursos() {
    const cursos = await this.cursosService.obtenerCursos();
    return { cursos };
  }

  @Get('crear')
  @Render('crear-curso')
  crearFormulario() {
    return {};
  }

  @Post('crear')
  @Redirect('/cursos')
  async crear(@Body() body: any) {
    await this.cursosService.crearCurso(body);
  }

  @Get('editar/:id')
  @Render('editar-curso')
  async editarFormulario(@Param('id') id: number) {
    const curso = await this.cursosService.obtenerCurso(id);
    return { curso };
  }

  @Post('editar/:id')
  @Redirect('/cursos')
  async editar(@Param('id') id: number, @Body() body: any) {
    await this.cursosService.actualizarCurso(id, body);
  }

  @Get('eliminar/:id')
  @Redirect('/cursos')
  async eliminar(@Param('id') id: number) {
    await this.cursosService.eliminarCurso(id);
  }
}
