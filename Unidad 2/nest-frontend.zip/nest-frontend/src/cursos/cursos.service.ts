import { Injectable } from '@nestjs/common';
import axios from 'axios';
@Injectable()
export class CursosService {
  private baseUrl = 'http://localhost:9090/api/cursos';
  async obtenerCursos() {
    const { data } = await axios.get(`${this.baseUrl}/all`);
    return data;
  }
  async obtenerCurso(id: number) {
    const { data } = await axios.get(`${this.baseUrl}/search/${id}`);
    return data;
  }
  async crearCurso(curso: any) {
    const { data } = await axios.post(`${this.baseUrl}/create`, curso);
    return data;
  }
  async actualizarCurso(id: number, curso: any) {
    const { data } = await axios.put(`${this.baseUrl}/update/${id}`, curso);
    return data;
  }
  async eliminarCurso(id: number) {
    await axios.delete(`${this.baseUrl}/delete/${id}`);
  }
}
