const baseUrl = 'http://localhost:9090/api/cursos';

export async function getAllCursos() {
  const res = await fetch(`${baseUrl}/all`);
  return res.json();
}

export async function createCurso(curso) {
  const res = await fetch(`${baseUrl}/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(curso),
  });
  return res.json();
}

export async function updateCurso(id, curso) {
  const res = await fetch(`${baseUrl}/update/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(curso),
  });
  return res.json();
}

export async function deleteCurso(id) {
  await fetch(`${baseUrl}/delete/${id}`, { method: 'DELETE' });
}
