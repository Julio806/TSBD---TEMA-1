const baseUrl = 'http://localhost:8090/api/students';

export async function getAllStudents() {
  const res = await fetch(baseUrl);
  return res.json();
}

export async function createStudent(student) {
  const res = await fetch(baseUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(student),
  });
  return res.json();
}

export async function updateStudent(id, student) {
  const res = await fetch(`${baseUrl}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(student),
  });
  return res.json();
}

export async function deleteStudent(id) {
  await fetch(`${baseUrl}/${id}`, { method: 'DELETE' });
}
